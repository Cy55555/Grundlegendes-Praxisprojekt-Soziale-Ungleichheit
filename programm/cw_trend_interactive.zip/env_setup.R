### env_setup.R ###
### Load packages and read data ###

## Required packages
packages <- c(
  "tidyr",
  "dplyr",
  "colorspace",
  "stringr",
  "ggrepel",
  "lubridate",
  "ggplot2",
  "plotly",
  "purrr",
  "knitr",
  "magrittr",
  "kableExtra",
  "readr",
  "patchwork",
  "RColorBrewer",
  "tidyverse",
  "cowplot"
)

## Load packages
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    warning(paste0("Package '", pkg, "' is not installed."))
  }
}

## Read all CSV files from Data folder
folder_path <- "Data/"
csv_files <- list.files(
  path = folder_path,
  pattern = "\\.csv$",
  full.names = TRUE,
  ignore.case = TRUE
)
for (file in csv_files) {
  var_name <- file
  var_name <- gsub("^Data/", "", var_name)
  var_name <- gsub("\\.csv$", "", var_name)
  var_name <- gsub("-", "_", var_name)
  data <- read.csv(file)
  assign(var_name, data)
}
